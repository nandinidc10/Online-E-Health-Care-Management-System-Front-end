﻿using Microsoft.EntityFrameworkCore;
using System;

namespace ProjectManagement.Shared
{
    public class PMContext : DbContext
    {
    }
}
