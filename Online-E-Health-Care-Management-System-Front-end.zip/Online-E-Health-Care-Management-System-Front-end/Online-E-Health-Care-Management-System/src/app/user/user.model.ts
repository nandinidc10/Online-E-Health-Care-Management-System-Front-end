

export class UserModel{
    firstName: string;
    lastName: string;
    password: string;
    email: string;
    id: number;
    isAdmin: boolean;
}